//
//  DateFormatTableViewCell.swift
//  diaryToDo
//
//  Created by Chae_Haram on 2022/03/31.
//

import UIKit

class DateFormatTableViewCell: UITableViewCell {

    @IBOutlet weak var selectedDateFormat: UIButton!
    @IBOutlet weak var typeDateFormat: UILabel!

}
