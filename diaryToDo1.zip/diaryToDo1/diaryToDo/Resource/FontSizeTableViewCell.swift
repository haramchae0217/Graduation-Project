//
//  FontSizeTableViewCell.swift
//  diaryToDo
//
//  Created by Chae_Haram on 2022/03/31.
//

import UIKit

class FontSizeTableViewCell: UITableViewCell {

    @IBOutlet weak var fontSizeSelectButton: UIButton!
    @IBOutlet weak var fontSizeLabel: UILabel!

}
