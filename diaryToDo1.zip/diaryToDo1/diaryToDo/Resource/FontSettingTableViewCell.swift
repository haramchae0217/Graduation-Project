//
//  FontSettingTableViewCell.swift
//  diaryToDo
//
//  Created by Chae_Haram on 2022/03/31.
//

import UIKit

class FontSettingTableViewCell: UITableViewCell {

    @IBOutlet weak var isSelectedFontButton: UIButton!
    @IBOutlet weak var fontSettingLabel: UILabel!

}
